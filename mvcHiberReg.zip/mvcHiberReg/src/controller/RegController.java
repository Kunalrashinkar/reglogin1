package controller;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import model.Reg;
import model.Admin;

@Controller
public class RegController {
	@RequestMapping("regload")
	public ModelAndView empload()
	{
		return new ModelAndView("regview","command",new Reg());
	}
	@RequestMapping(value="reglogic",method=RequestMethod.POST)
	public ModelAndView regLogic(@ModelAttribute("mvcHiberReg") Reg r)
	
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tx = ses.beginTransaction();
		ses.save(r);
		tx.commit();
		ses.close();
		ModelAndView obj= new ModelAndView("regview","command",new Reg());
		obj.addObject("res","Registration Successfully");
		return obj;
	}
	@RequestMapping("userlogin")
	public ModelAndView loginDemo(@ModelAttribute("mvcHiberReg") Reg r, ModelMap mp)
	{
		if(r!=null)
		{
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session ses = sf.openSession();
			Query q = ses.createQuery("from Reg e where e.userid=? and e.password=?");
			q.setLong(0,r.getUserid());
			q.setString(1,r.getPassword());
			List lst = q.list();
			if(lst.size()>0)
			{
				return new ModelAndView("redirect:feedload.do");
			}
			else
			{
				mp.addAttribute("key","Invalid userid and password");
				return new ModelAndView("userlogin","command",new Reg());
				
			}
		}
		mp.addAttribute("key","");
		return new ModelAndView("userlogin","command",new Reg());	
		
		
	}

}
