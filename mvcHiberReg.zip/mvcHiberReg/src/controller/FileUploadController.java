package controller;
import java.io.*;

import javax.persistence.Entity;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import model.Upload;

@Controller
@Entity
public class FileUploadController {
	@RequestMapping("/uploadview")
	public ModelAndView uploadview()
	{
		return new ModelAndView("uploadview");
	}
	
	@RequestMapping("/uploadlogic")
	public ModelAndView uploadlogic(@RequestParam CommonsMultipartFile file, HttpSession session) throws IOException
   {

		//ServletContext context = session.getServletContext();  
		// String path = context.getRealPath("images/");  
	String path = session.getServletContext().getRealPath("/")+"images";
       String filename = file.getOriginalFilename();
       System.out.println(path+" "+filename);
       
       byte[] bytes= file.getBytes();
       BufferedOutputStream stream  = new BufferedOutputStream(new FileOutputStream(new File(path+"/"+filename)));
       stream.write(bytes);
       stream.flush();
       stream.close();
       Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tx = ses.beginTransaction();
		Upload e= new Upload();
		e.setPath(filename);
		ses.save(e);
		tx.commit();
		ses.close();
       
		
		
       return new ModelAndView("uploadform","filesuccess",filename);
   }
}
