package controller;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import model.Feedback;
import model.Reg;

@Controller
public class FeedbackController {
     @RequestMapping("feedload")
     public ModelAndView feedload(HttpServletRequest request)
     {
    	 return new ModelAndView("feedview","command",new Feedback());
     }
     
     @RequestMapping(value="feedlogic",method=RequestMethod.POST)
 	public ModelAndView feedLogic(@ModelAttribute("mvcHiberReg") Feedback f)
 	
 	{
 		Configuration cfg = new Configuration();
 		cfg.configure("hibernate.cfg.xml");
 		SessionFactory sf = cfg.buildSessionFactory();
 		Session ses = sf.openSession();
 		Transaction tx = ses.beginTransaction();
 		ses.save(f);
 		tx.commit();
 		ses.close();
 		ModelAndView obj= new ModelAndView("feedview","command",new Feedback());
 		obj.addObject("res","Feedback Successfully");
 		return obj;
 	}
}
