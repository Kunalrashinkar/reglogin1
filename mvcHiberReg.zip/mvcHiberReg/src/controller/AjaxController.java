package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Feedback;
import model.Reg;

@Controller
public class AjaxController {
	
	@RequestMapping("ajaxload")
	public ModelAndView regLoad()
	{
		return new ModelAndView("ajaxview");
	}
    @RequestMapping("showdata")
    public ModelAndView regshowdata(HttpServletRequest req)
    {
    	 Configuration cfg = new Configuration();
         cfg.configure("hibernate.cfg.xml");
         SessionFactory sf = cfg.buildSessionFactory();
         Session ses = sf.openSession();
         
         Criteria cq= ses.createCriteria(Feedback.class);
         Criterion cn = Restrictions.like("feeddesc",req.getParameter("q"),MatchMode.START);
         cq.add(cn);
         List lst = cq.list();
         ModelAndView obj = new ModelAndView("searchview","key",lst);
         return obj;
        
    
    }
}
