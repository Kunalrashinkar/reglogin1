package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
public class Feedback {
@Id
private int id;
@Column
private int userid;
@Column
private String feeddesc;
@Column
private int rating;
@Column
private String facultyname ;
@Column
private String detaildesc;

@Column
private String feedbackdate;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
public String getFeeddesc() {
	return feeddesc;
}
public void setFeeddesc(String feeddesc) {
	this.feeddesc = feeddesc;
}
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
public String getFacultyname() {
	return facultyname;
}
public void setFacultyname(String facultyname) {
	this.facultyname = facultyname;
}
public String getDetaildesc() {
	return detaildesc;
}
public void setDetaildesc(String detaildesc) {
	this.detaildesc = detaildesc;
}
public String getFeedbackdate() {
	return feedbackdate;
}
public void setFeedbackdate(String feedbackdate) {
	this.feedbackdate = feedbackdate;
}





}
